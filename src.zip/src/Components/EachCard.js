import React from "react"
function EachCard(props) {


 return (
   

<div className="card" onclick="navigate()" 
style={{borderRadius: "20px", cursor: "pointer",marginRight: "15px",width: "250px" ,height:"250px",flexShrink: 0,boxShadow:"5px 5px grey"}}>
  <img className="card-img-top img-fluid" style={{borderRadius: "25px 25px 0px 0px", minHeight:"150px",maxHeight:"150px",width: "100%" ,height:"150px"}}
   src={require(props.Ecard.image+"")} alt="Card image cap"/>
  <div className="card-body">
    <a href="./login.html" ><h3 className="card-title" style={{width: "100%" ,height:"75px"}}>{props.Ecard.title}</h3></a>
  </div>
</div>




 )

}
 
export default EachCard