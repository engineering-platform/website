const algos = [
    {
        'id': 1,
        'img': "./search.jfif",
        'title': "Seaching"
    },
    {
        'id': 2,
        'img': "./sort.png",
        'title': "Sorting"
    },
    {
        'id': 3,
        'img': "./backtrack.jfif",
        'title': "Backtracking"
    },
    {
        'id': 4,
        'img': "./greedyalgo.jfif",
        'title': "Greedy"
    },
    {
        'id': 5,
        'img': "./d&c.png",
        'title': "Divide and Conqure"
    },
    {
        'id': 6,
        'img': "./math.jpg",
        'title': "Mathematical"
    },
    {
        'id': 7,
        'img': "./DP.jfif",
        'title': "Dynammic programming"
    },
    {
        'id': 8,
        'img': "./graphalgo.png",
        'title': "Graph"
    },
    {
        'id': 9,
        'img': "./pattern.png",
        'title': "Pattern searching"
    },
    {
        'id': 10,
        'img': "./branch-and-bound.png",
        'title': "Branch and bound"
    },
    {
        'id': 11,
        'img': "./binary_bit.jpg",
        'title': "Bit Manipulation"
    },
    {
        'id': 12,
        'img': "./geometric.jpg",
        'title': "Geometric"
    },
    {
        'id': 13,
        'img': "./gametheory.png",
        'title': "Game theory"
    },
    {
        'id': 14,
        'img': "./random.png",
        'title': "Randomized"
    },
    
]

export default algos