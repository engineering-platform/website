import React from "react"

import EachCard from "./Components/EachCard"
import algorithms from "./Components/algorithms.png";
import basicProgramming from "./Components/basic-programming.png";
import dataStructures from "./Components/data-structures.png";
import math from "./Components/math.png";
import ds from "./Datastructures";
import algos from "./Algorithms";
import Custombar from "./Components/Navbar.js"

function Cards() {
    const dsComponents = ds.map(structure => <EachCard key={structure.id} Ecard={{ image: structure.img, title: structure.title }} />)
    const algoComponents = algos.map(structure => <EachCard key={structure.id} Ecard={{ image: structure.img, title: structure.title }} />)
    const cardStyle={
      display: "flex",  
        overflowX: "scroll",
        flexShrink: 0,
        overflowScrolling: "touch",
        WebkitOverflowScrolling: "touch",
        WebkitScrollbarDisplay:"none",
        padding:"50px",
        margin:"20px",
        backgroundColor:"	#F0F0F0",    
    };
    
    
    return (
      <div style={{margin:"20px"}}>
        <div><Custombar style={{margin:"20px"}}/></div>
         <h1 style={{margin:"20px"}}>Data structures</h1>
        <div className="cardConatiner" style={cardStyle}>
          {dsComponents}
        </div>
        <h1 style={{margin:"20px"}}>Algorithms</h1>
         <div className="cardConatiner" style={cardStyle}>
         {algoComponents}
       </div>
       </div>
    )
}


export default Cards