const ds = [
    {
        'id': 1,
        'img': "./a.png",
        'title': "Array"
    },
    {
        'id': 2,
        'img': "./graph.png",
        'title': "Graph"
    },
    {
        'id': 3,
        'img': "./stacks.png",
        'title': "Stack"
    },
    {
        'id': 4,
        'img': "./queue.png",
        'title': "Queue"
    },
    {
        'id': 5,
        'img': "./BT.png",
        'title': "Binary Tree"
    },
    {
        'id': 6,
        'img': "./BST.png",
        'title': "Binary Search Tree"
    },
    {
        'id': 7,
        'img': "./linkedList.png",
        'title': "Linked List"
    },
    {
        'id': 8,
        'img': "./heap.png",
        'title': "Heap"
    },
    {
        'id': 9,
        'img': "./hashing.png",
        'title': "Hashing"
    },
]

export default ds